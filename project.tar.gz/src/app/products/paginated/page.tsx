import ProductsPagePaginated from '../page-paginated'

export default function PaginatedProductsPage() {
  return <ProductsPagePaginated />
}
